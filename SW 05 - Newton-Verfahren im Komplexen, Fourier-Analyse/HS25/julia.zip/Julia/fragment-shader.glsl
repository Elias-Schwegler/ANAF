precision highp float;

varying vec2 z0;


const float eps = 1E-16;
const int n = 1000;

const float eps2 = eps * eps;

const vec2 Z1 = vec2 ( 1.0,  1.0);
const vec2 Z2 = vec2 (-1.0,  0.0);
const vec2 Z3 = vec2 ( 1.0, -1.0);

const vec2 one   = vec2 (1.0, 0.0);
const vec2 two   = vec2 (2.0, 0.0);
const vec2 three = vec2 (3.0, 0.0);

const vec4 red   = vec4 (1.0, 0.0, 0.0, 1.0);
const vec4 green = vec4 (0.0, 1.0, 0.0, 1.0);
const vec4 blue  = vec4 (0.0, 0.0, 1.0, 1.0);


vec2 Mul (vec2 v, vec2 w)
{
    return vec2 (v.x * w.x - v.y * w.y, v.x * w.y + v.y * w.x);
}


vec2 Sqr (vec2 v)
{
    return Mul (v, v);
}


vec2 Conj (vec2 v)
{
    return vec2 (v.x, -v.y);
}


float Abs2 (vec2 v)
{
    return v.x * v.x + v.y * v.y;
}


vec2 Div (vec2 v, vec2 w)
{
    return Mul (v, Conj (w)) / Abs2 (w);
}


void main ()
{
    vec2 z = z0;

    for (int i = 0; i < n; ++i)
    {
        vec2 f1 = Mul (z, Mul (z, three) - two);
        if (Abs2 (f1) < eps2) break;
        vec2 f0 = Mul (Sqr (z), z - one) + two;
        z -= Div (f0, f1);

        if (Abs2 (z - Z1) < eps2) { gl_FragColor = red;   return; }
        if (Abs2 (z - Z2) < eps2) { gl_FragColor = green; return; }
        if (Abs2 (z - Z3) < eps2) { gl_FragColor = blue;  return; }
    }

    gl_FragColor = vec4 (0.0, 0.0, 0.0, 1.0);
}
