'use strict'



class Interval
{
    #Min
    #Max


    constructor (min, max)
    {
        this.#Min = min
        this.#Max = max
    }


    min ()
    {
        return this.#Min
    }


    max ()
    {
        return this.#Max
    }


    delta ()
    {
        return this.#Max - this.#Min
    }


    percent (coord)
    {
        return (coord - this.#Min) / this.delta()
    }


    coord (percent)
    {
        return this.#Min + percent * this.delta()
    }


    scale (coord, factor)
    {
        //  coord - factor * (coord - min) = (1 - factor) * coord + factor * min
        //  coord + factor * (max - coord) = (1 - factor) * coord + factor * max

        let f = (m) => (1.0 - factor) * coord + factor * m
        this.#Min = f (this.#Min)
        this.#Max = f (this.#Max)
    }


    move (dist)
    {
        this.#Min += dist
        this.#Max += dist
    }
}
