'use strict'



let canvas
let gl
let sp

let Screen
let World = new Rectangle (-5.0, 5.0, -4.0, 4.0)

let Move = false
let Pos0
let World0

let vertexBuffer
let indexBuffer

let aVertexLoc



window.onload = function ()
{
    canvas = document.getElementById ('myCanvas')
    canvas.onmousedown = MouseDown
    canvas.onmousemove = MouseMove
    canvas.onmouseup = MouseUp
    canvas.onwheel = Wheel

    let r = canvas.getBoundingClientRect()
    Screen = new Rectangle (r.left, r.right, r.bottom, r.top)

    gl = canvas.getContext ('webgl')
    MakeShader (gl, './vertex-shader.glsl', './fragment-shader.glsl')
        .then (sp => main (gl, sp))
}



function main (ggl, ssp)
{
    gl = ggl
    sp = ssp

    vertexBuffer = gl.createBuffer()
    aVertexLoc = gl.getAttribLocation (sp , 'aVertex')
    gl.enableVertexAttribArray (aVertexLoc)

    let indices = new Uint8Array
    ([
         0, 1, 2,
         0, 2, 3
    ])

    indexBuffer = gl.createBuffer()
    gl.bindBuffer (gl.ELEMENT_ARRAY_BUFFER, indexBuffer)
    gl.bufferData (gl.ELEMENT_ARRAY_BUFFER, indices, gl.STATIC_DRAW)

    gl.clearColor (0.0, 0.0, 0.0, 1.0)

    Draw()
}



function Draw ()
{
    console.log (World.xmin(), World.xmax(), World.xmax() - World.xmin())
    console.log (World.ymin(), World.ymax(), World.ymax() - World.ymin())
    console.log (Screen.slope(), World.slope())
    console.log ('---')

    let vertices = new Float32Array
    ([
        -1.0, -1.0, World.xmin(), World.ymin(),
         1.0, -1.0, World.xmax(), World.ymin(),
         1.0,  1.0, World.xmax(), World.ymax(),
        -1.0,  1.0, World.xmin(), World.ymax()
    ])

    gl.bindBuffer (gl.ARRAY_BUFFER, vertexBuffer)
    gl.bufferData (gl.ARRAY_BUFFER, vertices, gl.STATIC_DRAW)
    gl.vertexAttribPointer (aVertexLoc, 4, gl.FLOAT, false, 0, 0)

    gl.clear (gl.COLOR_BUFFER_BIT)
    gl.bindBuffer (gl.ELEMENT_ARRAY_BUFFER, indexBuffer)
    gl.drawElements (gl.TRIANGLES, 6, gl.UNSIGNED_BYTE, 0)
}



function MouseDown (ev)
{
    let spos = Screen.percent (ev.clientX, ev.clientY)
    Pos0 = World.coord (... spos)
    World0 = World;
    Move = true;
}



function MouseMove (ev)
{
    if (Move)
    {
        let spos = Screen.percent (ev.clientX, ev.clientY)
        let wpos = World.coord (... spos)
        World.move (Pos0 [0] - wpos [0], Pos0 [1] - wpos [1])
        Draw()
    }
}



function MouseUp (ev)
{
    MouseMove (ev)
    Move = false
}



function Wheel (ev)
{
    console.log (ev)
    let spos = Screen.percent (ev.clientX, ev.clientY)
    let wpos = World.coord (... spos)

    if (ev.deltaY < 0.0) World.scale (... wpos, 5.0 / 4.0)
    if (ev.deltaY > 0.0) World.scale (... wpos, 4.0 / 5.0)

    Draw()
}
