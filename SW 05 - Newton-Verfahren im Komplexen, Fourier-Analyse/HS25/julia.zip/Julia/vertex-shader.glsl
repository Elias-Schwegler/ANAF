attribute vec4 aVertex;

varying vec2 z0;

void main ()
{
    gl_Position = vec4 (aVertex.xy, 0.0, 1.0);
    z0 = aVertex.zw;
}
