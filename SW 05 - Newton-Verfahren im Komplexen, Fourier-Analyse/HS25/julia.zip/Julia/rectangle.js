'use strict'



class Rectangle
{
    #Xint
    #Yint


    constructor (xmin, xmax, ymin, ymax)
    {
        this.#Xint = new Interval (xmin, xmax)
        this.#Yint = new Interval (ymin, ymax)
    }


    xmin () { return this.#Xint.min() }
    xmax () { return this.#Xint.max() }

    ymin () { return this.#Yint.min() }
    ymax () { return this.#Yint.max() }


    percent (x, y)
    {
        return [this.#Xint.percent (x), this.#Yint.percent (y)]
    }


    coord (x, y)
    {
        return [this.#Xint.coord (x), this.#Yint.coord (y)]
    }


    scale (x, y, f)
    {
        this.#Xint.scale (x, f)
        this.#Yint.scale (y, f)
    }


    move (x, y)
    {
        this.#Xint.move (x)
        this.#Yint.move (y)
    }


    slope ()
    {
        return this.#Yint.delta() / this.#Xint.delta()
    }
}
