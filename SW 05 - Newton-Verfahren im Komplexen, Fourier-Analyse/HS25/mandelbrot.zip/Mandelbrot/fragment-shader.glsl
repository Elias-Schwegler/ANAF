precision highp float;

varying float x0;
varying float y0;

void main ()
{
    const int n = 1000;
    const float r = 5.0;

    float x = x0;
    float y = y0;
    float rr = r * r;

    for (int i = 0; i < n; ++i)
    {
        float xx = x * x;
        float yy = y * y;

        if (xx + yy > rr)
        {
            float c = min ((float (i) + 1.0) / 25.0, 1.0);
            gl_FragColor = vec4 (0.5 + 0.5 * c, c, 0.0, 1.0);
            return;
        }

        float t = xx - yy + x0;
        y = 2.0 * x * y + y0;
        x = t;
    }

    gl_FragColor = vec4 (0.0, 0.0, 0.0, 1.0);
}
