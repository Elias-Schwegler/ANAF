attribute vec4 aVertex;

varying float x0;
varying float y0;

void main ()
{
    x0 = aVertex [2];
    y0 = aVertex [3];
    gl_Position = vec4 (aVertex [0], aVertex [1], 0.0, 1.0);
}
